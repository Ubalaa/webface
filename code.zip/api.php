<?php
session_start();
require 'files/config.php';
$login = 0;
if($_GET['type'] == 'demo'){
    $login = 1;
    $tiengoc = 0;
}
if($_GET['type'] == 'primary'){
    if(isset($_SESSION['username'])){
        $login = 1;
    }
}
// Định rõ URL của API
if($login == 1){
    $url = 'https://fakebillck.org/banks/'.$_POST['key'].'/api.php?type='.$_GET['type'];
    $sodu = DB::queryFirstField("SELECT sodu FROM `users` WHERE username = '".$_SESSION['username']."'");
if($sodu >= $tiengoc){
    DB::query("UPDATE users SET sodu=sodu-$tiengoc WHERE username='".$_SESSION['username']."'");
// Dữ liệu POST
$postData = array(
    'key' => $webinfo['serial_key'],
    'loaichuyen' => $_POST['loaichuyen'],
    'theme' => $_POST['theme'],
    'time_dt' => $_POST['time_dt'],
    'pin' => $_POST['pin'],
    'stk_nhan' => $_POST['stk_nhan'],
    'code1' => $_POST['code1'],
    'name_nhan' => $_POST['name_nhan'],
    'amount' => $_POST['amount'],
    'bank_nhan' => $_POST['bank_nhan'],
    'code' => $_POST['code'],
    'magiaodich' => $_POST['magiaodich'],
    'noidung' => $_POST['noidung'],
    'bdsd' => $_POST['bdsd'],
    'sdc' => $_POST['sdc'],
    'name_gui' => $_POST['name_gui'],
    'stkgui' => $_POST['stkgui'],
    'time_bill' => $_POST['time_bill']
);

// Khởi tạo session cURL
$ch = curl_init();

// Thiết lập các tùy chọn cURL
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

// Thực hiện yêu cầu cURL
$response = curl_exec($ch);

// Kiểm tra lỗi cURL
if (curl_errno($ch)) {
    echo 'Lỗi cURL: ' . curl_error($ch);
}

// Đóng session cURL
curl_close($ch);

// Xử lý nội dung trả về (nếu cần)
echo $response;
}
 else {
    echo '<span style="color:red">Số dư không đủ vui lòng nạp thêm</span>';
}

} else {
    echo '<span style="color:red">Vui lòng đăng nhập vào tài khoản</span>';
}

?>