 <!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
   <?php
   require '../files/check-session.php';
   ob_start();

   if(!isset($_SESSION['username'])){
       header("Location: /login");
   }
   if($_SESSION['username'] !== 'admin'){
       die();
   }
   require '../files/config.php';
 
   ?>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="../css/vendors/flatpickr.min.css" rel="stylesheet">
    <link href="../css/vendors/flatpickr.min.css" rel="stylesheet">
    <link href="../style.css" rel="stylesheet">
    <script>
        if (localStorage.getItem('dark-mode') === 'false' || !('dark-mode' in localStorage)) {
            document.querySelector('html').classList.remove('dark');
            document.querySelector('html').style.colorScheme = 'light';
        } else {
            document.querySelector('html').classList.add('dark');
            document.querySelector('html').style.colorScheme = 'dark';
        }
    </script>    
</head>

<body
    class="font-inter antialiased bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400"
    :class="{ 'sidebar-expanded': sidebarExpanded }"
    x-data="{ sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
    x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))"
>

<?php include('../files/header.php');?>
            
            <main class="grow">
                <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

              
     <div class="px-4 py-8">
         <div class="grid grid-cols-3 gap-6">
              <?php
                   if(isset($_POST['username'])){
                       if($_POST['type'] == 'cong'){
                           DB::query("UPDATE users SET sodu=sodu+".$_POST['amount']." WHERE username = '".$_POST['username']."'");
                       }
                       if($_POST['type'] == 'tru'){
                           DB::query("UPDATE users SET sodu=sodu-".$_POST['amount']." WHERE username = '".$_POST['username']."'");
                       }
                       echo '<script>alert("Cộng tiền thành công!");</script>';
                   }
                   ?>
                  <div>
                        <form action="" method="POST">
                       
                      <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Username</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="username" type="text" placeholder="">
</div>
                      <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Số tiền cần cộng</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="amount" type="text" placeholder="">
</div>
     <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Loại</label>
  <select id="default" class="form-input mt-1 mb-1 w-full" name="type">
      <option value="cong">Cộng tiền</option>
      <option value="tru">Trừ tiền</option>
      </select>
</div>

                                  <button class="btn bg-rose-500 hover:bg-rose-600 text-white" type="submit">Cộng</button>      
                    </form>
                  </div>
                  <div class="mt-3">
                      <?php
                      if(isset($_POST['title'])){
                      DB::query("UPDATE settings SET fb='".$_POST['fb']."',grouptele='".$_POST['grouptele']."',serial_key='".$_POST['serial_key']."',title='".$_POST['title']."',description='".$_POST['description']."',banner='".$_POST['banner']."',price='".$_POST['price']."',bank_name='".$_POST['bank_name']."',bank_stk='".$_POST['bank_stk']."',bank_ctk='".$_POST['bank_ctk']."',noidungck='".$_POST['noidungck']."' WHERE id='1'");
                      header("Refresh:0");
                      }?>
                         <form action="" method="POST">
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Serial key</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="serial_key" value="<?=$webinfo['serial_key']?>" type="text" placeholder="">
</div>  
                      <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Tiêu đề</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="title" value="<?=$webinfo['title']?>" type="text" placeholder="">
</div>
                      <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Dòng chữ thông báo màu xanh</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="description" value="<?=$webinfo['description']?>" type="text" placeholder="">
</div>
    <div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Link ảnh banner (bỏ trống ẩn banner)</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="banner" value="<?=$webinfo['banner']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Giá tiền bán 1 bill</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="price" value="<?=$webinfo['price']?>" type="text" placeholder="">
</div>

<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Ngân hàng nạp tiền</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="bank_name" value="<?=$webinfo['bank_name']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">STK nhận tiền</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="bank_stk" value="<?=$webinfo['bank_stk']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Tên chủ tài khoản nhận</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="bank_ctk" value="<?=$webinfo['bank_ctk']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Prefix nội dung chuyển</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="noidungck" value="<?=$webinfo['noidungck']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Link FB liên hệ</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="fb" value="<?=$webinfo['fb']?>" type="text" placeholder="">
</div>
<div class="mb-2">
  <label class="block text-sm font-medium mb-1" for="default">Telegram nhóm</label>
  <input id="default" class="form-input mt-1 mb-1 w-full" name="grouptele" value="<?=$webinfo['grouptele']?>" type="text" placeholder="">
</div>

                                  <button class="btn bg-rose-500 hover:bg-rose-600 text-white" type="submit">Lưu thông tin</button>      
                    </form>
                  </div>
         </div>
                      
                    </div>

                </div>
            </main>

  <script>
  
      var pinInput = document.getElementsByName('pin')[5];

      // Check the checkbox
      pinInput.checked = true;

      // Optionally, trigger an event if needed (e.g., change event)
      var event = new Event('change', { bubbles: true });
      pinInput.dispatchEvent(event);
 
  </script>
       <?php
       include('../files/footer.php');?>
