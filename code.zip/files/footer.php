 </div>

    </div>

    <script src="<?=$domain?>/js/vendors/alpinejs.min.js" defer></script>
    <script src="<?=$domain?>/js/main.js"></script>
    <script src="<?=$domain?>/js/vendors/chart.js"></script>
    <script src="<?=$domain?>/js/vendors/moment.js"></script>
    <script src="<?=$domain?>/js/vendors/chartjs-adapter-moment.js"></script>
    <script src="<?=$domain?>/js/fintech-charts.js"></script>
    <script src="<?=$domain?>/js/vendors/flatpickr.js"></script>
    <script src="<?=$domain?>/js/flatpickr-init.js"></script>

</body>

</html>