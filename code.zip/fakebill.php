<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="utf-8">
   <?php
   require 'files/check-session.php';

   require 'files/config.php';
   use Melbahja\Seo\MetaTags;
$user = array(
    'name' => xss_clean($_GET['name']),
    'file_name' => xss_clean($_GET['name']));
$metatags = new MetaTags();
session_start();
$metatags
        ->title('Fake bill chuyển tiền ngân hàng '.$user['name'])
        ->description('Dịch vụ fake bill Vietcombank,Sacombank,MBBank,...')
        ->meta('author', 'Mohamed Elabhja')
        ->image('https://avatars3.githubusercontent.com/u/8259014');

echo $metatags;

   ?>
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <link href="./css/vendors/flatpickr.min.css" rel="stylesheet">
    <link href="./css/vendors/flatpickr.min.css" rel="stylesheet">
    <link href="./style.css" rel="stylesheet">
    <script>
        if (localStorage.getItem('dark-mode') === 'false' || !('dark-mode' in localStorage)) {
            document.querySelector('html').classList.remove('dark');
            document.querySelector('html').style.colorScheme = 'light';
        } else {
            document.querySelector('html').classList.add('dark');
            document.querySelector('html').style.colorScheme = 'dark';
        }
    </script>    
</head>

<body
    class="font-inter antialiased bg-slate-100 dark:bg-slate-900 text-slate-600 dark:text-slate-400"
    :class="{ 'sidebar-expanded': sidebarExpanded }"
    x-data="{ sidebarOpen: false, sidebarExpanded: localStorage.getItem('sidebar-expanded') == 'true' }"
    x-init="$watch('sidebarExpanded', value => localStorage.setItem('sidebar-expanded', value))"
>

<?php include('files/header.php');?>
            
            <main class="grow">
                <div class="px-4 sm:px-6 lg:px-8 py-8 w-full max-w-9xl mx-auto">

              
     <div class="px-4 py-8">
                        <div class="">
    
                            <h1 class="text-3xl text-slate-800 dark:text-slate-100 font-bold mb-6">Fake bill chuyển tiền ngân hàng <?=$user['name']?></h1>
                        
                              <?php
$file_name = $user['file_name']; // Đảm bảo biến $user['file_name'] đã được định nghĩa trước đó

// Khởi tạo một session cURL
$ch = curl_init();

// Thiết lập URL và các tùy chọn cURL
$url = $domain_api . '/banks/' . $file_name . '/create.php?name='.$file_name;
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // Đặt để trả về nội dung thay vì in ra màn hình

// Thực hiện yêu cầu cURL
$response = curl_exec($ch);

// Kiểm tra lỗi cURL
if (curl_errno($ch)) {
    echo 'Lỗi cURL: ' . curl_error($ch);
}

// Đóng session cURL
curl_close($ch);


// Use preg_replace to replace the number in the button text
$response = preg_replace('/Tạo bill \(\d+,\d+\)/', 'Tạo bill (' . number_format($tiengoc) . 'đ)', $response);
$response =  str_replace('key: "",','key: "'.$file_name.'",',$response);
echo str_replace('https://fakebillck.org/banks/'.$file_name.'/api.php',$domain.'/api.php',$response);
?>

    
                        </div>
                    </div>

                </div>
            </main>
<script>
     var pinInput = document.getElementsByName('pin')[5];

      // Check the checkbox
      pinInput.checked = true;

      // Optionally, trigger an event if needed (e.g., change event)
      var event = new Event('change', { bubbles: true });
      pinInput.dispatchEvent(event);
 
  </script>

       <?php
       include('files/footer.php');?>